# bronze_ingestion.py — Synapse PySpark (Bronze Raw Ingestion)
# Author: Your Name | BatchID: XYZ
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.types import *
from pyspark.sql.functions import *

# ====== CONFIG ======
ADLS_ACCOUNT = "stcapstone"   # replace with your storage account name
CONTAINER_BRONZE = "bronze"
CONTAINER_QUAR = "quarantine"
BRONZE = f"abfss://{CONTAINER_BRONZE}@{ADLS_ACCOUNT}.dfs.core.windows.net"
QUAR   = f"abfss://{CONTAINER_QUAR}@{ADLS_ACCOUNT}.dfs.core.windows.net"

BATCH_ID = dbutils.widgets.get("batch_id") if 'dbutils' in globals() else "batch_001"
SOURCE_SYSTEM = dbutils.widgets.get("source_system") if 'dbutils' in globals() else "capstone_simulated"

spark = SparkSession.builder.getOrCreate()

# Control table path (Delta or Parquet)
CONTROL_PATH = f"{BRONZE}/_control/processed_batches/"

def already_processed(batch_id: str) -> bool:
    try:
        df = spark.read.parquet(CONTROL_PATH)
        return df.filter(col("batch_id") == batch_id).limit(1).count() > 0
    except Exception:
        return False

def mark_processed(batch_id: str, table_name: str, count: int):
    spark.createDataFrame([(batch_id, table_name, count, current_timestamp())],
                          "batch_id string, table string, row_count long, processed_at timestamp")          .write.mode("append").parquet(CONTROL_PATH)

# ====== Schemas (from BA spec) ======
customer_schema = StructType([
    StructField("customer_id", StringType()),
    StructField("customer_key", LongType()),
    StructField("customer_name", StringType()),
    StructField("email", StringType()),
    StructField("phone", StringType()),
    StructField("segment", StringType()),
    StructField("branch_id", StringType()),
    StructField("branch_name", StringType()),
    StructField("region", StringType()),
    StructField("country", StringType()),
    StructField("city", StringType()),
    StructField("risk_score", DoubleType()),
    StructField("risk_category", StringType()),
    StructField("risk_profile", StringType()),
    StructField("onboard_date", DateType()),
    StructField("customer_tenure_days", IntegerType()),
    StructField("customer_status", StringType()),
    StructField("created_at", TimestampType()),
    StructField("updated_at", TimestampType())
])

accounts_schema = StructType([
    StructField("account_id", StringType()),
    StructField("customer_key", LongType()),
    StructField("account_type", StringType()),
    StructField("balance", DecimalType(18,2)),
    StructField("currency", StringType()),
    StructField("account_status", StringType()),
    StructField("open_date", DateType()),
    StructField("interest_rate", DecimalType(6,3))
])

transactions_schema = StructType([
    StructField("txn_id", StringType()),
    StructField("customer_key", LongType()),
    StructField("account_ref", StringType()),
    StructField("amount", DecimalType(18,2)),
    StructField("currency", StringType()),
    StructField("channel", StringType()),
    StructField("txn_type", StringType()),
    StructField("status", StringType()),
    StructField("error_flag", BooleanType()),
    StructField("rejection_reason", StringType()),
    StructField("processing_time_sec", DecimalType(10,3)),
    StructField("sla_breached", BooleanType()),
    StructField("source_system", StringType()),
    StructField("record_hash", StringType()),
    StructField("reconciliation_status", StringType()),
    StructField("txn_timestamp", TimestampType()),
    StructField("created_at", TimestampType())
])

trades_schema = StructType([
    StructField("trade_id", StringType()),
    StructField("customer_key", LongType()),
    StructField("portfolio_id", StringType()),
    StructField("instrument_type", StringType()),
    StructField("ticker", StringType()),
    StructField("exchange", StringType()),
    StructField("trade_side", StringType()),
    StructField("quantity", IntegerType()),
    StructField("price", DecimalType(10,2)),
    StructField("cost_basis", DecimalType(10,2)),
    StructField("market_price", DecimalType(10,2)),
    StructField("trade_value", DecimalType(18,2)),
    StructField("realized_pnl", DecimalType(18,2)),
    StructField("unrealized_pnl", DecimalType(18,2)),
    StructField("total_pnl", DecimalType(18,2)),
    StructField("commission", DecimalType(10,4)),
    StructField("status", StringType()),
    StructField("error_flag", BooleanType()),
    StructField("rejection_reason", StringType()),
    StructField("processing_time_sec", DecimalType(10,3)),
    StructField("sla_breached", BooleanType()),
    StructField("source_system", StringType()),
    StructField("record_hash", StringType()),
    StructField("reconciliation_status", StringType()),
    StructField("trade_timestamp", TimestampType()),
    StructField("created_at", TimestampType())
])

market_prices_schema = StructType([
    StructField("ticker", StringType()),
    StructField("price_date", DateType()),
    StructField("open_price", DecimalType(10,2)),
    StructField("close_price", DecimalType(10,2)),
    StructField("high_price", DecimalType(10,2)),
    StructField("low_price", DecimalType(10,2)),
    StructField("volume", LongType()),
    StructField("adj_close", DecimalType(10,2))
])

audit_log_schema = StructType([
    StructField("audit_id", StringType()),
    StructField("source_table", StringType()),
    StructField("record_id", StringType()),
    StructField("operation", StringType()),
    StructField("performed_by", StringType()),
    StructField("source_system", StringType()),
    StructField("outcome", StringType()),
    StructField("change_summary", StringType()),
    StructField("event_timestamp", TimestampType())
])

# ====== Helpers ======

def ingest_table(table: str, fmt: str, schema: StructType, src_path: str):
    if already_processed(BATCH_ID):
        print(f"Batch {BATCH_ID} already processed. Skipping.")
        return
    reader = spark.read.format(fmt)
    if fmt == 'csv':
        reader = reader.option('header', True)
    df = reader.schema(schema).load(src_path)          .withColumn('ingestion_timestamp', current_timestamp())          .withColumn('source_file_path', input_file_name())          .withColumn('batch_id', lit(BATCH_ID))          .withColumn('source_system', lit(SOURCE_SYSTEM))

    # Basic validation example
    if table == 'customers':
        valid = df.filter(col('customer_key').isNotNull())
        invalid = df.exceptAll(valid)
    elif table == 'transactions':
        valid = df.filter(col('txn_id').isNotNull() & col('txn_timestamp').isNotNull())
        invalid = df.exceptAll(valid)
    else:
        valid = df
        invalid = spark.createDataFrame([], df.schema)

    # Write valid to Bronze; invalid to Quarantine
    valid.write.mode('append').parquet(f"{BRONZE}/{table}/")
    if invalid.count() > 0:
        (invalid.withColumn('rejection_reason', lit('Schema/Rule violation'))
               .write.mode('append').parquet(f"{QUAR}/{table}/"))

    mark_processed(BATCH_ID, table, valid.count())

# Example calls (set your landing paths)
ingest_table('customers', 'csv', customer_schema,  f"{BRONZE}/landing/customers/*.csv")
ingest_table('accounts', 'parquet', accounts_schema, f"{BRONZE}/landing/accounts/*.parquet")
ingest_table('transactions', 'parquet', transactions_schema, f"{BRONZE}/landing/transactions/*.parquet")
ingest_table('trades', 'parquet', trades_schema, f"{BRONZE}/landing/trades/*.parquet")
ingest_table('market_prices', 'parquet', market_prices_schema, f"{BRONZE}/landing/market_prices/*.parquet")
ingest_table('audit_log', 'parquet', audit_log_schema, f"{BRONZE}/landing/audit_log/*.parquet")
