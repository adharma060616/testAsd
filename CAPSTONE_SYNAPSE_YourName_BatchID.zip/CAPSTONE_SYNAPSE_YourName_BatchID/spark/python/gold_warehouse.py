# gold_warehouse.py — Synapse PySpark (Gold Star Schema Builder)
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.window import Window

ADLS_ACCOUNT = "stcapstone"
SILVER = f"abfss://silver@{ADLS_ACCOUNT}.dfs.core.windows.net"
GOLD   = f"abfss://gold@{ADLS_ACCOUNT}.dfs.core.windows.net"

spark = SparkSession.builder.getOrCreate()

# Load Silver
customers = spark.read.parquet(f"{SILVER}/customers/")
accounts  = spark.read.parquet(f"{SILVER}/accounts/")
trx       = spark.read.parquet(f"{SILVER}/transactions/")
trades    = spark.read.parquet(f"{SILVER}/trades/")
mp        = spark.read.parquet(f"{SILVER}/market_prices/")

# ===== DimDate (10 years)
from datetime import date, timedelta
start = date(2018,1,1); end = date(2028,12,31)
rows=[]; i=1; d=start
while d<=end:
    rows.append((i, d, d.day, d.month, (d.month-1)//3+1, d.year, int(d.strftime('%W')), 1 if d.weekday()>=5 else 0, 0))
    d += timedelta(days=1); i+=1
DimDate = spark.createDataFrame(rows, 'dim_date_sk int, full_date date, day int, month int, quarter int, year int, week int, is_weekend int, is_holiday int')
DimDate.write.mode('overwrite').parquet(f"{GOLD}/dim_date/")

# ===== DimBranch (derived from customers)
DimBranch = customers.select('branch_id','branch_name','city','region','country').dropDuplicates()    .withColumn('dim_branch_sk', monotonically_increasing_id())    .select('dim_branch_sk','branch_id','branch_name','city','region','country')
DimBranch.write.mode('overwrite').parquet(f"{GOLD}/dim_branch/")

# ===== DimInstrument (derived from trades)
DimInstrument = trades.select('ticker','instrument_type','exchange').dropDuplicates()    .withColumn('dim_instrument_sk', monotonically_increasing_id())    .select('dim_instrument_sk','ticker','instrument_type','exchange')
DimInstrument.write.mode('overwrite').parquet(f"{GOLD}/dim_instrument/")

# ===== DimProduct (derived)
DimProduct = spark.createDataFrame([
    (1,'CASA','CASA'),(2,'Savings','SAV'),(3,'Current','CUR'),(4,'Equity','EQ'),(5,'Bond','BD'),(6,'Derivative','DRV')
], 'dim_product_sk int, product_type string, product_code string')
DimProduct.write.mode('overwrite').parquet(f"{GOLD}/dim_product/")

# ===== DimCustomer (SCD Type-2)
w = Window.partitionBy('customer_key').orderBy(col('updated_at').asc_nulls_last())
DimCustomer = (customers
    .withColumn('eff_from', coalesce(col('updated_at'), current_timestamp()))
    .withColumn('eff_to', lead('updated_at',1).over(w))
    .withColumn('is_current', when(col('eff_to').isNull(), lit(1)).otherwise(lit(0)))
    .withColumn('dim_customer_sk', monotonically_increasing_id())
)
DimCustomer.write.mode('overwrite').parquet(f"{GOLD}/dim_customer/")

# ===== DimAccount (with balance_band)
DimAccount = (accounts
    .withColumn('balance_band', when(col('balance')<1000,'<1k')
                                 .when(col('balance')<10000,'1k-10k')
                                 .when(col('balance')<100000,'10k-100k')
                                 .otherwise('100k+'))
    .withColumn('dim_account_sk', monotonically_increasing_id())
    .select('dim_account_sk','account_id','customer_key','account_type','balance_band','currency','account_status','open_date','interest_rate')
)
DimAccount.write.mode('overwrite').parquet(f"{GOLD}/dim_account/")

# ===== FactRetailTransactions
FactRetail = (trx
    .join(DimCustomer.select('customer_key','dim_customer_sk'), 'customer_key','left')
    .join(DimBranch.select('branch_id','dim_branch_sk'), on=trx['customer_key']==customers['customer_key'], how='left')
)
# Simplify joins by recomputing branch via customers
fact_retail = (trx.alias('t')
    .join(customers.select('customer_key','branch_id'),'customer_key','left')
    .join(DimBranch,'branch_id','left')
    .join(DimCustomer.select('customer_key','dim_customer_sk'),'customer_key','left')
    .withColumn('dim_date_sk', col('t.txn_date').cast('date'))
    .select(
        'customer_key','dim_customer_sk','dim_branch_sk',
        col('t.account_ref').alias('account_ref'),
        col('t.txn_id').alias('txn_id'),
        col('t.amount').alias('amount'),
        col('t.amount_usd').alias('amount_usd'),
        col('t.channel').alias('channel'),
        col('t.status').alias('status'),
        col('t.txn_type').alias('txn_type'),
        col('t.processing_time_sec').alias('processing_time_sec'),
        col('t.sla_breached').alias('sla_breached'),
        col('t.error_flag').alias('error_flag'),
        col('t.rejection_reason').alias('rejection_reason'),
        col('t.txn_timestamp').alias('txn_timestamp')
    )
)
fact_retail.write.mode('overwrite').parquet(f"{GOLD}/fact_retail_transactions/")

# ===== FactInvestmentTrades
fact_trades = (trades.alias('tr')
    .join(DimCustomer.select('customer_key','dim_customer_sk'),'customer_key','left')
    .join(DimInstrument,'ticker','left')
    .withColumn('trade_date', to_date('tr.trade_timestamp'))
    .select(
        'customer_key','dim_customer_sk','dim_instrument_sk',
        col('tr.trade_id').alias('trade_id'), 'quantity','price','trade_value',
        'realized_pnl','unrealized_pnl','total_pnl','commission','trade_side','status',
        col('tr.trade_timestamp').alias('trade_timestamp')
    )
)
fact_trades.write.mode('overwrite').parquet(f"{GOLD}/fact_investment_trades/")

# ===== Holdings (customer × ticker × day)
latest_price = mp.groupBy('ticker').agg(max('price_date').alias('maxd'))     .join(mp, (mp.ticker==latest_price.ticker) & (mp.price_date==latest_price.maxd), 'inner')     .select(mp['ticker'], mp['close_price'])

buy_trades = trades.filter(col('trade_side')=='BUY')     .groupBy('customer_key','ticker')     .agg(sum('quantity').alias('units_held'), sum(col('quantity')*col('price')).alias('cost_basis_total'))

holdings = buy_trades.join(latest_price,'ticker','left')     .withColumn('market_value_usd', (col('units_held')*col('close_price')).cast('decimal(18,2)'))     .join(DimInstrument,'ticker','left')     .join(DimCustomer.select('customer_key','dim_customer_sk'),'customer_key','left')     .withColumn('dim_date_sk', lit(None).cast('int'))     .select('customer_key','dim_customer_sk','dim_instrument_sk','dim_date_sk','units_held','market_value_usd','cost_basis_total')

holdings.write.mode('overwrite').parquet(f"{GOLD}/fact_portfolio_holdings/")

# ===== DailyPnL (aggregation)
daily_pnl = (trades
    .withColumn('trade_date', to_date('trade_timestamp'))
    .groupBy('customer_key','trade_date')
    .agg(sum('realized_pnl').alias('daily_realized_pnl'), sum('unrealized_pnl').alias('daily_unrealized_pnl'))
)

w_p = Window.partitionBy('customer_key').orderBy('trade_date').rowsBetween(Window.unboundedPreceding, Window.currentRow)
daily_pnl = daily_pnl.withColumn('cumulative_pnl', sum(col('daily_realized_pnl')+col('daily_unrealized_pnl')).over(w_p))     .withColumn('dim_date_sk', col('trade_date'))     .join(DimCustomer.select('customer_key','dim_customer_sk'),'customer_key','left')     .select('customer_key','dim_customer_sk','dim_date_sk','daily_realized_pnl','daily_unrealized_pnl','cumulative_pnl')

daily_pnl.write.mode('overwrite').parquet(f"{GOLD}/fact_daily_pnl/")
