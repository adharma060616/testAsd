# silver_transform.py — Synapse PySpark (Silver Cleansed Layer)
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window

ADLS_ACCOUNT = "stcapstone"
SILVER = f"abfss://silver@{ADLS_ACCOUNT}.dfs.core.windows.net"
BRONZE = f"abfss://bronze@{ADLS_ACCOUNT}.dfs.core.windows.net"
QUAR   = f"abfss://quarantine@{ADLS_ACCOUNT}.dfs.core.windows.net"

spark = SparkSession.builder.getOrCreate()

# FX rate broadcast map (static example)
fx = spark.createDataFrame([
    ("USD", 1.0), ("INR", 0.012), ("EUR", 1.1)
], "currency string, usd_rate double")
fx = broadcast(fx)

# Customers
cust = spark.read.parquet(f"{BRONZE}/customers/")
# Deduplicate by customer_key using updated_at
w_c = Window.partitionBy('customer_key').orderBy(col('updated_at').desc_nulls_last())
customers_silver = (cust
    .withColumn('rn', row_number().over(w_c))
    .filter(col('rn')==1)
    .drop('rn')
    .select('*')
)
customers_silver.write.mode('overwrite').parquet(f"{SILVER}/customers/")

# Accounts (no major business rules here)
accounts = spark.read.parquet(f"{BRONZE}/accounts/")
accounts_silver = accounts.dropDuplicates(['account_id'])
accounts_silver.write.mode('overwrite').parquet(f"{SILVER}/accounts/")

# Transactions — business rules + FX normalization
trx = spark.read.parquet(f"{BRONZE}/transactions/")
trx_clean = (trx
    .filter(col('amount') > 0)
    .filter(col('txn_timestamp').isNotNull())
    .withColumn('txn_date', to_date('txn_timestamp'))
)
trx_dedup = trx_clean.dropDuplicates(['txn_id'])
trx_fx = (trx_dedup
    .join(fx, on='currency', how='left')
    .withColumn('amount_usd', (col('amount') * col('usd_rate')).cast('decimal(18,2)'))
)
# Partition by date & channel per spec
trx_fx.write.mode('overwrite').partitionBy('txn_date','channel').parquet(f"{SILVER}/transactions/")

# Trades — validations + referential integrity with customers
tr = spark.read.parquet(f"{BRONZE}/trades/")
tr_clean = (tr
    .filter(col('quantity') > 0)
    .filter(col('trade_timestamp').isNotNull())
)
# RI check: only trades with existing customer_key
valid_trades = tr_clean.join(customers_silver.select('customer_key').distinct(), 'customer_key', 'inner')
valid_trades.write.mode('overwrite').partitionBy(to_date('trade_timestamp').alias('trade_date')).parquet(f"{SILVER}/trades/")

# Market prices — keep last per day per ticker
mp = spark.read.parquet(f"{BRONZE}/market_prices/")
w_m = Window.partitionBy('ticker','price_date').orderBy(col('close_price').desc())
mp_silver = (mp.withColumn('rn', row_number().over(w_m)).filter(col('rn')==1).drop('rn'))
mp_silver.write.mode('overwrite').parquet(f"{SILVER}/market_prices/")

# Audit log — passthrough
al = spark.read.parquet(f"{BRONZE}/audit_log/").dropDuplicates(['audit_id'])
al.write.mode('overwrite').parquet(f"{SILVER}/audit_log/")
