package com.capstone;
import org.apache.spark.sql.*;
import org.apache.spark.sql.types.*;
import static org.apache.spark.sql.functions.*;

public class BronzeIngestion {
    public static void main(String[] args) {
        String account = System.getenv().getOrDefault("ADLS_ACCOUNT","stcapstone");
        String BRONZE = String.format("abfss://%s@%s.dfs.core.windows.net", "bronze", account);
        String QUAR   = String.format("abfss://%s@%s.dfs.core.windows.net", "quarantine", account);
        SparkSession spark = SparkSession.builder().appName("BronzeIngestion").getOrCreate();

        StructType customerSchema = new StructType()
            .add("customer_id","string").add("customer_key","long").add("customer_name","string")
            .add("email","string").add("phone","string").add("segment","string")
            .add("branch_id","string").add("branch_name","string").add("region","string")
            .add("country","string").add("city","string").add("risk_score","double")
            .add("risk_category","string").add("risk_profile","string")
            .add("onboard_date","date").add("customer_tenure_days","int")
            .add("customer_status","string").add("created_at","timestamp").add("updated_at","timestamp");

        Dataset<Row> df = spark.read().format("csv").option("header",true).schema(customerSchema)
            .load(BRONZE + "/landing/customers/*.csv")
            .withColumn("ingestion_timestamp", current_timestamp())
            .withColumn("source_file_path", input_file_name());

        Column validCond = col("customer_key").isNotNull();
        Dataset<Row> valid = df.filter(validCond);
        Dataset<Row> invalid = df.filter(validCond.not());

        valid.write().mode("append").parquet(BRONZE + "/customers/");
        if (invalid.count() > 0) {
            invalid.withColumn("rejection_reason", lit("Missing customer_key"))
                   .write().mode("append").parquet(QUAR + "/customers/");
        }
    }
}
