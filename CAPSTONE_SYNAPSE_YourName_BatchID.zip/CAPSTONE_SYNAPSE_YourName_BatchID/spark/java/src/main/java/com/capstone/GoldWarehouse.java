package com.capstone;
import org.apache.spark.sql.*;
import static org.apache.spark.sql.functions.*;

public class GoldWarehouse {
    public static void main(String[] args) {
        String account = System.getenv().getOrDefault("ADLS_ACCOUNT","stcapstone");
        String SILVER = String.format("abfss://%s@%s.dfs.core.windows.net", "silver", account);
        String GOLD   = String.format("abfss://%s@%s.dfs.core.windows.net", "gold", account);
        SparkSession spark = SparkSession.builder().appName("GoldWarehouse").getOrCreate();
        Dataset<Row> customers = spark.read().parquet(SILVER + "/customers/");
        Dataset<Row> dimCustomer = customers.withColumn("eff_from", coalesce(col("updated_at"), current_timestamp()))
            .withColumn("eff_to", lit(null))
            .withColumn("is_current", lit(1));
        dimCustomer.write().mode("overwrite").parquet(GOLD + "/dim_customer/");
    }
}
