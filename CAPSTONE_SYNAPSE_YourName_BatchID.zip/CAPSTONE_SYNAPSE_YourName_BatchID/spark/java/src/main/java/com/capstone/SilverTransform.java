package com.capstone;
import org.apache.spark.sql.*;
import org.apache.spark.sql.expressions.Window;
import org.apache.spark.sql.expressions.WindowSpec;
import static org.apache.spark.sql.functions.*;

public class SilverTransform {
    public static void main(String[] args) {
        String account = System.getenv().getOrDefault("ADLS_ACCOUNT","stcapstone");
        String SILVER = String.format("abfss://%s@%s.dfs.core.windows.net", "silver", account);
        String BRONZE = String.format("abfss://%s@%s.dfs.core.windows.net", "bronze", account);
        SparkSession spark = SparkSession.builder().appName("SilverTransform").getOrCreate();

        Dataset<Row> customers = spark.read().parquet(BRONZE + "/customers/");
        WindowSpec w = Window.partitionBy("customer_key").orderBy(col("updated_at").desc());
        Dataset<Row> dedup = customers.withColumn("rn", row_number().over(w))
                                      .filter(col("rn").equalTo(1)).drop("rn");
        dedup.write().mode("overwrite").parquet(SILVER + "/customers/");
    }
}
