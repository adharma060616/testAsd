# Submission Manifest
- Spark (Bronze/Silver/Gold): `spark/python/*.py`
- Java Spark (optional +10): `spark/java/src/main/java/com/capstone/*.java`
- SQL DDL: `sql/ddl/*.sql`  |  SQL Loads: `sql/load/*.sql` | Utilities: `sql/utilities/*.sql`
- Synapse Pipelines: export your ARM as `pipelines/arm_template/*` (screenshots in `pipelines/screenshots/*`)
- Power BI: `powerbi/Measures/CAPSTONE_KPIS.dax` (PBIX to be added)
- Architecture Diagram: `diagrams/architecture_simple.mmd`
- Assumptions/Trade-offs: `docs/assumptions_and_tradeoffs.pdf` (simple .md included)
- Evidence: `evidence/*`
