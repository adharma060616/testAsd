-- 90_post_load_checks.sql — Simple row count checks
SELECT 'DimCustomer' AS table_name, COUNT(*) AS cnt FROM dbo.DimCustomer
UNION ALL SELECT 'DimAccount', COUNT(*) FROM dbo.DimAccount
UNION ALL SELECT 'DimBranch', COUNT(*) FROM dbo.DimBranch
UNION ALL SELECT 'DimInstrument', COUNT(*) FROM dbo.DimInstrument
UNION ALL SELECT 'DimDate', COUNT(*) FROM dbo.DimDate
UNION ALL SELECT 'DimProduct', COUNT(*) FROM dbo.DimProduct
UNION ALL SELECT 'FactRetailTransactions', COUNT(*) FROM dbo.FactRetailTransactions
UNION ALL SELECT 'FactInvestmentTrades', COUNT(*) FROM dbo.FactInvestmentTrades
UNION ALL SELECT 'FactPortfolioHoldings', COUNT(*) FROM dbo.FactPortfolioHoldings
UNION ALL SELECT 'FactDailyPnL', COUNT(*) FROM dbo.FactDailyPnL;
