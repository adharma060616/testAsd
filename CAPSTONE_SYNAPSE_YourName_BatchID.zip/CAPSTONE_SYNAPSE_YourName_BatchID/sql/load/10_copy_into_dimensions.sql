-- 10_copy_into_dimensions.sql — Load Gold Parquet into SQL Pool tables
COPY INTO dbo.DimDate FROM 'https://stcapstone.dfs.core.windows.net/gold/dim_date/'
WITH (FILE_TYPE='PARQUET');
COPY INTO dbo.DimBranch FROM 'https://stcapstone.dfs.core.windows.net/gold/dim_branch/'
WITH (FILE_TYPE='PARQUET');
COPY INTO dbo.DimInstrument FROM 'https://stcapstone.dfs.core.windows.net/gold/dim_instrument/'
WITH (FILE_TYPE='PARQUET');
COPY INTO dbo.DimProduct FROM 'https://stcapstone.dfs.core.windows.net/gold/dim_product/'
WITH (FILE_TYPE='PARQUET');
COPY INTO dbo.DimAccount FROM 'https://stcapstone.dfs.core.windows.net/gold/dim_account/'
WITH (FILE_TYPE='PARQUET');
COPY INTO dbo.DimCustomer FROM 'https://stcapstone.dfs.core.windows.net/gold/dim_customer/'
WITH (FILE_TYPE='PARQUET');
