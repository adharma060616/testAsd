-- 11_copy_into_facts.sql — Load Facts
COPY INTO dbo.FactRetailTransactions FROM 'https://stcapstone.dfs.core.windows.net/gold/fact_retail_transactions/'
WITH (FILE_TYPE='PARQUET');
COPY INTO dbo.FactInvestmentTrades FROM 'https://stcapstone.dfs.core.windows.net/gold/fact_investment_trades/'
WITH (FILE_TYPE='PARQUET');
COPY INTO dbo.FactPortfolioHoldings FROM 'https://stcapstone.dfs.core.windows.net/gold/fact_portfolio_holdings/'
WITH (FILE_TYPE='PARQUET');
COPY INTO dbo.FactDailyPnL FROM 'https://stcapstone.dfs.core.windows.net/gold/fact_daily_pnl/'
WITH (FILE_TYPE='PARQUET');
