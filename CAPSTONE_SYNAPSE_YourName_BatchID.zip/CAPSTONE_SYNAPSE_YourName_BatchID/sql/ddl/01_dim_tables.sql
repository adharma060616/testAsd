-- 01_dim_tables.sql — Create Dimensions (best-practice distribution)
CREATE SCHEMA IF NOT EXISTS dbo;

IF OBJECT_ID('dbo.DimCustomer') IS NOT NULL DROP TABLE dbo.DimCustomer;
CREATE TABLE dbo.DimCustomer (
    dim_customer_sk     BIGINT IDENTITY(1,1) NOT NULL,
    customer_key        BIGINT NOT NULL,
    customer_id         VARCHAR(100),
    customer_name       VARCHAR(200),
    email               VARCHAR(200),
    phone               VARCHAR(50),
    segment             VARCHAR(50),
    branch_id           VARCHAR(20),
    branch_name         VARCHAR(200),
    region              VARCHAR(100),
    country             VARCHAR(100),
    city                VARCHAR(100),
    risk_score          DECIMAL(5,2),
    risk_category       VARCHAR(50),
    risk_profile        VARCHAR(50),
    onboard_date        DATE,
    customer_tenure_days INT,
    customer_status     VARCHAR(50),
    eff_from            DATETIME2,
    eff_to              DATETIME2,
    is_current          BIT,
    CONSTRAINT PK_DimCustomer PRIMARY KEY (dim_customer_sk)
) WITH (DISTRIBUTION = HASH(customer_key), CLUSTERED COLUMNSTORE INDEX);

IF OBJECT_ID('dbo.DimAccount') IS NOT NULL DROP TABLE dbo.DimAccount;
CREATE TABLE dbo.DimAccount (
    dim_account_sk BIGINT IDENTITY(1,1),
    account_id     VARCHAR(100),
    customer_key   BIGINT,
    account_type   VARCHAR(50),
    balance_band   VARCHAR(50),
    currency       VARCHAR(10),
    account_status VARCHAR(50),
    open_date      DATE,
    interest_rate  DECIMAL(6,3),
    CONSTRAINT PK_DimAccount PRIMARY KEY (dim_account_sk)
) WITH (DISTRIBUTION = HASH(customer_key), CLUSTERED COLUMNSTORE INDEX);

IF OBJECT_ID('dbo.DimBranch') IS NOT NULL DROP TABLE dbo.DimBranch;
CREATE TABLE dbo.DimBranch (
    dim_branch_sk BIGINT IDENTITY(1,1),
    branch_id     VARCHAR(20),
    branch_name   VARCHAR(200),
    city          VARCHAR(100),
    region        VARCHAR(100),
    country       VARCHAR(100),
    CONSTRAINT PK_DimBranch PRIMARY KEY (dim_branch_sk)
) WITH (DISTRIBUTION = REPLICATE, HEAP);

IF OBJECT_ID('dbo.DimInstrument') IS NOT NULL DROP TABLE dbo.DimInstrument;
CREATE TABLE dbo.DimInstrument (
    dim_instrument_sk BIGINT IDENTITY(1,1),
    ticker            VARCHAR(20),
    instrument_type   VARCHAR(50),
    exchange          VARCHAR(50),
    CONSTRAINT PK_DimInstrument PRIMARY KEY (dim_instrument_sk)
) WITH (DISTRIBUTION = REPLICATE, HEAP);

IF OBJECT_ID('dbo.DimDate') IS NOT NULL DROP TABLE dbo.DimDate;
CREATE TABLE dbo.DimDate (
    dim_date_sk  INT NOT NULL,
    full_date    DATE,
    day          TINYINT,
    month        TINYINT,
    quarter      TINYINT,
    year         SMALLINT,
    week         TINYINT,
    is_weekend   BIT,
    is_holiday   BIT,
    CONSTRAINT PK_DimDate PRIMARY KEY (dim_date_sk)
) WITH (DISTRIBUTION = REPLICATE, HEAP);

IF OBJECT_ID('dbo.DimProduct') IS NOT NULL DROP TABLE dbo.DimProduct;
CREATE TABLE dbo.DimProduct (
    dim_product_sk BIGINT IDENTITY(1,1),
    product_type   VARCHAR(50),
    product_code   VARCHAR(50),
    CONSTRAINT PK_DimProduct PRIMARY KEY (dim_product_sk)
) WITH (DISTRIBUTION = REPLICATE, HEAP);
