-- 02_fact_tables.sql — Create Facts (best-practice distribution)
IF OBJECT_ID('dbo.FactRetailTransactions') IS NOT NULL DROP TABLE dbo.FactRetailTransactions;
CREATE TABLE dbo.FactRetailTransactions (
    fact_retail_sk       BIGINT IDENTITY(1,1),
    customer_key         BIGINT NOT NULL,
    dim_customer_sk      BIGINT,
    dim_branch_sk        BIGINT,
    dim_date_sk          DATE,
    account_ref          VARCHAR(100),
    txn_id               VARCHAR(100),
    amount               DECIMAL(18,2),
    amount_usd           DECIMAL(18,2),
    channel              VARCHAR(50),
    status               VARCHAR(50),
    txn_type             VARCHAR(50),
    processing_time_sec  DECIMAL(10,3),
    sla_breached         BIT,
    error_flag           BIT,
    rejection_reason     VARCHAR(200),
    txn_timestamp        DATETIME2,
    CONSTRAINT PK_FactRetail PRIMARY KEY (fact_retail_sk)
) WITH (DISTRIBUTION = HASH(customer_key), CLUSTERED COLUMNSTORE INDEX);

IF OBJECT_ID('dbo.FactInvestmentTrades') IS NOT NULL DROP TABLE dbo.FactInvestmentTrades;
CREATE TABLE dbo.FactInvestmentTrades (
    fact_trade_sk       BIGINT IDENTITY(1,1),
    customer_key        BIGINT NOT NULL,
    dim_customer_sk     BIGINT,
    dim_instrument_sk   BIGINT,
    dim_date_sk         DATE,
    trade_id            VARCHAR(100),
    quantity            INT,
    price               DECIMAL(18,4),
    trade_value         DECIMAL(18,2),
    realized_pnl        DECIMAL(18,2),
    unrealized_pnl      DECIMAL(18,2),
    total_pnl           DECIMAL(18,2),
    commission          DECIMAL(10,4),
    trade_side          VARCHAR(10),
    status              VARCHAR(50),
    trade_timestamp     DATETIME2,
    CONSTRAINT PK_FactTrade PRIMARY KEY (fact_trade_sk)
) WITH (DISTRIBUTION = HASH(customer_key), CLUSTERED COLUMNSTORE INDEX);

IF OBJECT_ID('dbo.FactPortfolioHoldings') IS NOT NULL DROP TABLE dbo.FactPortfolioHoldings;
CREATE TABLE dbo.FactPortfolioHoldings (
    fact_hold_sk        BIGINT IDENTITY(1,1),
    customer_key        BIGINT NOT NULL,
    dim_customer_sk     BIGINT,
    dim_instrument_sk   BIGINT,
    dim_date_sk         DATE,
    units_held          DECIMAL(18,4),
    market_value_usd    DECIMAL(18,2),
    cost_basis_total    DECIMAL(18,2),
    CONSTRAINT PK_FactHold PRIMARY KEY (fact_hold_sk)
) WITH (DISTRIBUTION = HASH(customer_key), CLUSTERED COLUMNSTORE INDEX);

IF OBJECT_ID('dbo.FactDailyPnL') IS NOT NULL DROP TABLE dbo.FactDailyPnL;
CREATE TABLE dbo.FactDailyPnL (
    fact_pnl_sk         BIGINT IDENTITY(1,1),
    customer_key        BIGINT,
    dim_customer_sk     BIGINT,
    dim_date_sk         DATE,
    daily_realized_pnl  DECIMAL(18,2),
    daily_unrealized_pnl DECIMAL(18,2),
    cumulative_pnl       DECIMAL(18,2),
    CONSTRAINT PK_FactPnl PRIMARY KEY (fact_pnl_sk)
) WITH (DISTRIBUTION = ROUND_ROBIN, CLUSTERED COLUMNSTORE INDEX);
