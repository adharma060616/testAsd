# Assumptions & Trade-offs (Simple)
- `customer_key` is the universal join key; timestamps are UTC.
- Silver performs schema casting, dedupe, FX normalization, and RI checks.
- Gold contains 6 dims + 4 facts; SCD2 only on DimCustomer.
- SQL Pool used only for consumption; loads via COPY INTO.
- Distribution: HASH for large dims/facts on customer_key; REPLICATE for small dims; ROUND_ROBIN for DailyPnL.
- Import mode in Power BI; DAX measures implement KPI logic.
