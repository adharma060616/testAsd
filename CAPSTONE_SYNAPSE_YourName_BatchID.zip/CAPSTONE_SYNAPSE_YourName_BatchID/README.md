# CAPSTONE — Synapse Unified Banking Analytics (Submission Package)

This package contains all deliverables for the Enterprise Banking Analytics Capstone.

## How to Run (Quickstart)
1. **Synapse Spark (Bronze → Silver → Gold)**
   - Upload `spark/python/*.py` to Synapse Studio Notebooks or Jobs.
   - Configure the constants at the top (ADLS `abfss://` paths).
   - Execute notebooks in order: bronze_ingestion.py → silver_transform.py → gold_warehouse.py.
2. **Create SQL Objects in Synapse Dedicated SQL Pool**
   - Run `sql/ddl/01_dim_tables.sql` then `sql/ddl/02_fact_tables.sql`.
   - Load data with `sql/load/10_copy_into_dimensions.sql` then `sql/load/11_copy_into_facts.sql`.
3. **Power BI**
   - Open `powerbi/dashboards.pbix` (add later) or create a new PBIX and import `powerbi/Measures/CAPSTONE_KPIS.dax`.
   - Connect to Synapse SQL Pool tables created in step 2.

## Contents
- Spark code (Python + Java optional bonus) — Bronze/Silver/Gold
- SQL DDL (6 dims + 4 facts) and COPY INTO scripts
- DAX measures file with 23 KPIs
- Mermaid architecture diagram (simple)
- Assumptions & Trade-offs document
- Pipelines placeholders (add your exported ARM template)
- Evidence folders for run logs and DQ outputs

## Notes
- Warehouse is consumption-only (no transformations in SQL Pool).
- SCD Type-2 implemented on DimCustomer.
- Distribution strategy: HASH / REPLICATE / ROUND_ROBIN as per best practices.
